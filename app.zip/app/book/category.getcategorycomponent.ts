import { Component, OnInit } from '@angular/core';
import { Category } from '../beans/category';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'get-category',
    templateUrl: 'category.getcategory.html'
})

export class GetCategoryComponent{
 constructor(private categoryService: CategoryService, private router: Router) { }
    category: any = {};

    getCategory(): any {
        this.categoryService.getCategory(this.category);
    }
}