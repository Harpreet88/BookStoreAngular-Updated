import { Component, OnInit } from '@angular/core';
import { Category } from '../beans/category';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'remove-category',
    templateUrl: 'category.removecategory.html'
})

export class RemoveCategoryComponent{
 constructor(private categoryService: CategoryService, private router: Router) { }
    category: any = {};

    removeCategory(): any {
        this.categoryService.removeCategory(this.category);
    }
}