import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class CategoryService {

    constructor(private httpdata: HttpClient) { }

    addCategory(category: any) {

        console.log(category.id);
        let input = new FormData();

        input.append("categoryName", category.name);

        return this.httpdata.post("http://localhost:9999/add_Category", input);
    }
    removeCategory(category:any){
        let input = new FormData();
        input.append("categoryId", category.id);

        return this.httpdata.delete("http://localhost:9999/remove_Category", input);
    }
    getCategory(category:any){
        let input = new FormData();
        input.append("categoryId", category.id);

        return this.httpdata.get("http://localhost:9999/category_Details", input);
    }
    getAllCategories(){
        return this.httpdata.get("http://localhost:9999/category_List");
    }
    updateCategory(category: any){
         let input = new FormData();
        input.append("categoryId", category.id); 
        input.append("categoryName", category.name);
        return this.httpdata.post("http://localhost:9999/update_Category",input);
    }
}