import { Component, OnInit } from '@angular/core';
import { Customer } from '../beans/customer';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'remove-customer',
    templateUrl: 'customer.removecustomer.html'
})

export class RemoveCustomerComponent{
 constructor(private customerService: CustomerService, private router: Router) { }
 customer: any = {};

    removeCustomer(): any {
        this.customerService.removeCustomer(this.customer);
    }
}