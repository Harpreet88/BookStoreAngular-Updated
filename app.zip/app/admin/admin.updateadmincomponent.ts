import { Component, OnInit } from '@angular/core';
import { Admin } from '../beans/admin';
import { AdminService } from '../services/admin.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'update-admin',
    templateUrl: 'admin.updateadmin.html'
})
export class UpdateAdminComponent {

    constructor(private adminService: AdminService, private router: Router) { }
    admin: any = {};

    updateAdmin(): any {
        this.adminService.updateAdmin(this.admin);
    }
}