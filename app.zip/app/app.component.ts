﻿import { Component } from '@angular/core';
import { CategoryService } from './services/category.services';
import { CustomerService } from './services/customer.services';
import{AdminService}from './services/admin.services';
@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent { 
     constructor(private cateService:CategoryService){}
cateAll:any[];

constructor(private customerService:CustomerService){}
constructor(private adminService:AdminService){}

//  ngOnInit(){

// this.bookService.addCategory().subscribe((data:any)=>this.prodAll=(data));
 }

