import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class CustomerService {

    constructor(private httpdata: HttpClient) { }

    addCustomer(customer: any) {

        console.log(customer.id);
        let input = new FormData();

        input.append("Customer Id", customer.customerId);
        input.append("Customer Name", customer.fullName);
        input.append("Customer Email Id",customer.email);
        input.append("Customer password",customer.password);
        input.append("Customer Phone Number",customer.phoneNumber);
        input.append("Customer Address",customer.address);
        input.append("Customer City",customer.city);
        input.append("Customer Country",customer.country);
        input.append("Customer Zip Code",customer.zipCode);


        return this.httpdata.post("http://localhost:9999/add_Customer", input);
    }
    getAllCustomers(){
        return this.httpdata.get("http://localhost:9999/customer_List");
    }
    removeCustomer(customer:any){
        let input = new FormData();
        input.append("customerId", customer.id);

        return this.httpdata.delete("http://localhost:9999/remove_Customer", input);
    }
    getustomer(customer:any){
        let input = new FormData();
        input.append("customerId", customer.id);

        return this.httpdata.get("http://localhost:9999/customer_Details", input);
    }
}