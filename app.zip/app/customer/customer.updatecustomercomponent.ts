import { Component, OnInit } from '@angular/core';
import { Customer } from '../beans/customer';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'update-customer',
    templateUrl: 'customer.updatecustomer.html'
})
export class UpdateCustomerComponent {

    constructor(private customerService: CustomerService, private router: Router) { }
    customer: any = {};

    updateCustomer(): any {
        this.customerService.updateCustomer(this.customer);
    }
}