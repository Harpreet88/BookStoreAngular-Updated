import { Component, OnInit } from '@angular/core';
import { Admin } from '../beans/admin';
import { AdminService } from '../services/admin.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'get-admin',
    templateUrl: 'admin.getadmin.html'
})

export class GetAdminComponent{
 constructor(private adminService: AdminService, private router: Router) { }
    admin: any = {};

    getAdmin(): any {
        this.adminService.getAdmin(this.admin);
    }
}