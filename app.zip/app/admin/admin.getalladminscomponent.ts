import { Component, OnInit } from '@angular/core';
import { Admin } from '../beans/admin';
import { AdminService } from '../services/admin.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'getall-admins',
    templateUrl: 'admin.getalladmins.html'
})

export class GetAllAdminsComponent{
 constructor(private adminService: AdminService, private router: Router) { }
    admin: any = {};

    getAllAdmins(): any {
        this.adminService.getAllAdmin();
    }
}