import { Component, OnInit } from '@angular/core';
import { Category } from '../beans/category';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'add-category',
    templateUrl: 'category.addcategory.html'
})
export class AddCategoryComponent {

    constructor(private categoryService: CategoryService, private router: Router) { }
    category: any = {};

    addCategory(): any {
        this.categoryService.addCategory(this.category);
    }
}