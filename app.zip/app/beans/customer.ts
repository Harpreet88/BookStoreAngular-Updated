
export class Customer {
    customerId:number;
    email:string;
    fullName:number;
    password:string;
    phoneNumber:number;
    address:number;
    city:string;
    country:string;
    zipCode:string;
    books: Book[];
}