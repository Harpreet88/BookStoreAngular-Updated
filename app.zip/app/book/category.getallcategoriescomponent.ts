import { Component, OnInit } from '@angular/core';
import { Category } from '../beans/category';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'getall-category',
    templateUrl: 'category.getallcategories.html'
})

export class GetAllCategoriesComponent{
 constructor(private categoryService: CategoryService, private router: Router) { }
    category: any = {};

    getAllCategories(): any {
        this.categoryService.getAllCategories();
    }
}