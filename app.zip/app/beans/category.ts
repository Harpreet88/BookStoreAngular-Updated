import {Book} from './book'

export class Category {
    categoryId:number;
    categoryName:string;
    books: Book[]
}