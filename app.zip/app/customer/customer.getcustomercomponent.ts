import { Component, OnInit } from '@angular/core';
import { Customer } from '../beans/customer';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'get-customer',
    templateUrl: 'customer.getCustomer.html'
})

export class GetCustomerComponent{
 constructor(private customeryService: CustomerService, private router: Router) { }
    customer: any = {};

    getCategory(): any {
        this.customerService.getCustomer(this.customer);
    }
}