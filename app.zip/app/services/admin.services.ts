import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class AdminService {

    constructor(private httpdata: HttpClient) { }

    addAdmin(admin: any) {

        console.log(admin.id);
        let input = new FormData();

        input.append("AdminName", admin.name);

        return this.httpdata.post("http://localhost:9999/add_Admin", input);
    }
    removeAdmin(admin:any){
        let input = new FormData();
        input.append("AdminId", admin.id);

        return this.httpdata.delete("http://localhost:9999/remove_Admin", input);
    }
    getAdmin(admin:any){
        let input = new FormData();
        input.append("AdminId", admin.id);

        return this.httpdata.get("http://localhost:9999/admin_Details", input);
    }
    getAllAdmin(){
        return this.httpdata.get("http://localhost:9999/admin_List");
    }
    updateAdmin(admin: any){
         let input = new FormData();
        input.append("adminId", admin.id); 
        input.append("admin Name", admin.name);
        return this.httpdata.post("http://localhost:9999/update_Admin",input);
    }
}