export class Book {
    bookId: number
    title: String
    author: String
    description: String
    ISBN: String
    imagePath: String
    price: number
}