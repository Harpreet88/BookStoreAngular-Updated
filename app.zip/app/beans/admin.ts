export class Admin{
adminId:number;
    emailId:string;
    fullName:string;
     password:string;}