import { Component, OnInit } from '@angular/core';
import { Admin } from '../beans/admin';
import { AdminService } from '../services/admin.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'add-admin',
    templateUrl: 'admin.addadmin.html'
})
export class AddAdminComponent {

    constructor(private adminService: AdminService, private router: Router) { }
    admin: any = {};

    addAdmin(): any {
        this.adminService.addAdmin(this.admin);
    }
}