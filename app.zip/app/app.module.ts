﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';

import {AddCategoryComponent} from './category/category.addcategorycomponent';
import {RemoveCategoryComponent} from './category/category.removecategorycomponent';
import {GetCategoryComponent} from './category/category.getcategorycomponent';
import {GetAllCategoriesComponent} from './category/category.getallcategoriescomponent';
import {UpdateCategoryComponent} from './category/category.updatecategorycomponent';

import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {Routes, RouterModule} from '@angular/router';

import{AddCustomerComponent}from './customer/customer.addcustomercomponent';
import{GetAllCustomerComponent}from './customer/customer.getallcustomercomponent';
import {GetCustomerComponent}from './customer/customer.getcustomercomponent'
import {RemoveCustomerComponent}from './customer/customer.removecustomercomponent'
import {UpdateCustomerComponent}from './customer/customer.updatecustomercomponent'

import{AddAdminComponent}from './admin/admin.addAdminComponent';
import{GetAllAdminsComponent}from './admin/admin.getalladminscomponent'
import {GetAdminComponent}from './admin/admin.getadmincomponent'
import {RemoveAdminComponent}from './admin/admin.removeadmincomponent'
import {UpdateAdminComponent}from './admin/admin.updateadmincomponent'




//Route Configuration
const routes:Routes=[
    {path:'add',component:AddCategoryComponent},
    {path:'remove',component:RemoveCategoryComponent},
    {path:'get',component:GetCategoryComponent},
    {path:'getAll',component:GetAllCategoriesComponent},
    {path:'update',component:UpdateCategoryComponent},
    
//Customer PAth
    {path:'addCustomer',component:AddCustomerComponent},
    {path:'getAllCustomer',component:GetAllCustomerComponent},
    {path:'getCustomer',component:GetCustomerComponent},
    {path:'updateCustomer',component:UpdateCustomerComponent},
    {path:'removeCustomer',component:RemoveCustomerComponent},
 //Admin path
 {path:'addAdmin',component:AddAdminComponent},
 {path:'getAllAdmin',component:GetAllAdminsComponent},
 {path:'getAdmin',component:AddAdminComponent},
 {path:'updateAdmin',component:UpdateAdminComponent},
 {path:'removeAdmin',component:RemoveAdminComponent},

]

@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(routes)
        
    ],
    declarations: [
        AppComponent,
        AddCategoryComponent,RemoveCategoryComponent,GetCategoryComponent,GetAllCategoriesComponent,UpdateCategoryComponent,
        AddCustomerComponent,RemoveCustomerComponent,GetCustomerComponent,GetAllCustomerComponent,UpdateCustomerComponent,
        AddAdminComponent,RemoveAdminComponent,GetAdminComponent,GetAllAdminsComponent,UpdateAdminComponent

		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }