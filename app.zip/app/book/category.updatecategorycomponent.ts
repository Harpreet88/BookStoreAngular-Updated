import { Component, OnInit } from '@angular/core';
import { Category } from '../beans/category';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'update-category',
    templateUrl: 'category.updatecategory.html'
})
export class UpdateCategoryComponent {

    constructor(private categoryService: CategoryService, private router: Router) { }
    category: any = {};

    updateCategory(): any {
        this.categoryService.updateCategory(this.category);
    }
}