import { Component, OnInit } from '@angular/core';
import { Admin } from '../beans/admin';
import { AdminService } from '../services/admin.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'remove-admin',
    templateUrl: 'admin.removeadmin.html'
})

export class RemoveAdminComponent{
 constructor(private adminService: AdminService, private router: Router) { }
    admin: any = {};

    removeAdmin(): any {
        this.adminService.removeAdmin(this.admin);
    }
}