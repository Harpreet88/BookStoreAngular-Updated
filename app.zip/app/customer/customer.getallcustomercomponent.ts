import { Component, OnInit } from '@angular/core';
import { Category } from '../beans/category';
import { CategoryService } from '../services/category.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'getall-customer',
    templateUrl: 'category.getallcustomer.html'
})

export class GetAllCustomerComponent{
 constructor(private customerService: CustomerService, private router: Router) { }
customer: any = {};

    getAllCustomer(): any {
        this.customerService.getAllCustomer();
    }
}