import { Component, OnInit } from '@angular/core;
import { Category } from '../beans/category';
import { CategoryService } from '../services/customer.services';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'add-category',
    templateUrl: 'category.addcategory.html'
})
export class AddCustomerComponent {

    constructor(private customerService:CustomerService, private router: Router) { }
    customer: any = {};

    addCustomer(): any {
        this.customerService.addCustomer(this.customer);
    }
}